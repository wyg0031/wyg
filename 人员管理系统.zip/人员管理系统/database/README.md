# 数据库初始化说明

## 使用方式

### 方式一：使用SQL脚本初始化

1. 确保MySQL数据库服务已启动
2. 执行SQL脚本：
   ```bash
   mysql -u root -p < init.sql
   ```
   或者在MySQL客户端中：
   ```sql
   source init.sql
   ```

### 方式二：使用Spring Boot自动创建

项目已配置为自动创建数据表（`spring.jpa.hibernate.ddl-auto=update`），只需要：

1. 创建数据库：
   ```sql
   CREATE DATABASE personnel_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. 配置 `application.properties` 中的数据库连接信息

3. 启动项目，系统会自动创建所有表

4. 系统启动时会自动创建默认超级管理员账号（如果不存在）

## 默认超级管理员账号

- **用户名（身份证号）**: 000000000000000000
- **密码**: admin123
- **角色**: 超级管理员

**请首次登录后及时修改密码！**

## 数据库结构说明

### 1. users（用户表）
存储系统用户信息，包括超级管理员和普通用户

### 2. registration_codes（注册码表）
存储用户注册时使用的注册码

### 3. members（团员信息表）
存储团员的基本信息

### 4. activities（活动记录表）
存储活动的基本信息

### 5. activity_participants（活动参与人员表）
存储活动的参与人员信息

### 6. volunteers（志愿者信息表）
存储志愿者的个人信息

## 注意事项

1. 数据库字符集使用 `utf8mb4`，支持中文和emoji
2. 身份证号字段设置为唯一索引
3. 所有表都包含创建时间和更新时间字段
4. 密码以明文存储（生产环境建议使用加密存储）

