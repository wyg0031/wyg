# 人员管理系统

基于Spring Boot开发的人员管理系统，支持团员信息、活动记录、志愿者信息的管理。

## 技术栈

- Java 8+
- Spring Boot 2.7.14
- Spring Data JPA
- MySQL 8.0
- Thymeleaf
- Apache POI（Excel/Word处理）

## 功能特性

1. **用户管理**
   - 使用身份证号作为用户名登录
   - 注册需要注册码
   - 超级管理员和普通用户权限区分

2. **团员信息管理**
   - 添加、删除、搜索团员信息
   - 批量导入Excel
   - 导出Excel表格

3. **活动记录管理**
   - 添加、删除、搜索活动
   - 活动时间不能跨天
   - 自动计算活动时长
   - 批量上传参与人员

4. **志愿者信息管理**
   - 批量导入志愿者信息

5. **全局搜索**
   - 搜索团员、活动、志愿者信息
   - 支持导出Word和Excel

6. **账号管理**
   - 超级管理员可管理所有账号
   - 普通用户只能修改自己信息
   - 生成注册码

## 数据库配置

修改 `src/main/resources/application.properties` 中的数据库配置：

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/personnel_db?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai
spring.datasource.username=root
spring.datasource.password=root
```

## 运行项目

1. 确保已安装MySQL数据库
2. 创建数据库：`CREATE DATABASE personnel_db;`
3. 运行项目：`mvn spring-boot:run`
4. 访问：http://localhost:8080

## 默认配置

- 系统会自动创建数据表
- 系统首次启动时会自动创建默认超级管理员账号：
  - **用户名（身份证号）**: 000000000000000000
  - **密码**: admin123
  - 请首次登录后及时修改密码！

## Excel导入格式

### 团员信息导入格式
| 姓名 | 性别 | 身份证号 | 出生年月 | 民族 | 手机号码 | 政治面貌 | 团员发展编号 | 入团时间 |
|------|------|----------|----------|------|----------|----------|--------------|----------|
| 张三 | 男   | 123456789012345678 | 20020330 | 汉 | 13800138000 | 团员 | 001 | 2015-03 |

### 活动参与人员导入格式
| 活动名称 | 姓名 |
|----------|------|
| 活动1 | 张三 |

