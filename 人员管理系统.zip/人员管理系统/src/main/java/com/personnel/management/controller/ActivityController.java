package com.personnel.management.controller;

import com.personnel.management.entity.Activity;
import com.personnel.management.entity.Member;
import com.personnel.management.repository.MemberRepository;
import com.personnel.management.service.ActivityService;
import com.personnel.management.service.ExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpSession;
import com.personnel.management.entity.User;

@Controller
@RequestMapping("/activities")
public class ActivityController {
    @Autowired
    private ActivityService activityService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private ExportService exportService;

    @GetMapping
    public String list(@RequestParam(required = false) String keyword, Model model, HttpSession session) {
        List<Activity> activities;
        if (keyword != null && !keyword.isEmpty()) {
            activities = activityService.search(keyword);
        } else {
            activities = activityService.findAll();
        }
        model.addAttribute("activities", activities);
        model.addAttribute("keyword", keyword);
        model.addAttribute("members", memberRepository.findAll());
        model.addAttribute("activeMenu", "activities");
        model.addAttribute("user", session.getAttribute("user"));
        return "activities";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute Activity activity,
                     @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime startTime,
                     @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime endTime,
                     @RequestParam(required = false) List<String> participantNames) {
        // 验证时间不能跨天
        if (!startTime.toLocalDate().equals(endTime.toLocalDate())) {
            // 如果跨天，可以提示错误或处理
            return "redirect:/activities?error=时间不能跨天";
        }
        
        activity.setStartTime(startTime);
        activity.setEndTime(endTime);
        Activity saved = activityService.save(activity);
        
        if (participantNames != null && !participantNames.isEmpty()) {
            activityService.addParticipants(saved.getId(), participantNames);
        }
        
        return "redirect:/activities";
    }

    @PostMapping("/upload-participants")
    public String uploadParticipants(@RequestParam("file") MultipartFile file, Model model) {
        try {
            activityService.importParticipantsFromExcel(file);
            model.addAttribute("success", "导入成功");
        } catch (Exception e) {
            model.addAttribute("error", "导入失败: " + e.getMessage());
        }
        return "redirect:/activities";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        activityService.delete(id);
        return "redirect:/activities";
    }
}

