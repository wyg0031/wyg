package com.personnel.management.controller;

import com.personnel.management.entity.User;
import com.personnel.management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/users")
public class UserManagementController {
    @Autowired
    private UserService userService;

    @GetMapping
    public String list(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        model.addAttribute("isAdmin", "ADMIN".equals(currentUser.getRole()));
        model.addAttribute("activeMenu", "users");
        model.addAttribute("user", currentUser);
        
        if ("ADMIN".equals(currentUser.getRole())) {
            model.addAttribute("users", userService.findAll());
        } else {
            model.addAttribute("users", java.util.Arrays.asList(currentUser));
        }
        return "users";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute User user, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if ("ADMIN".equals(currentUser.getRole())) {
            userService.save(user);
        }
        return "redirect:/users";
    }

    @PostMapping("/update")
    public String update(@ModelAttribute User user, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        User existing = userService.findById(user.getId());
        if (existing != null) {
            if ("ADMIN".equals(currentUser.getRole()) || existing.getId().equals(currentUser.getId())) {
                if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                    existing.setPassword(user.getPassword());
                }
                if (user.getName() != null) {
                    existing.setName(user.getName());
                }
                userService.save(existing);
            }
        }
        return "redirect:/users";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if ("ADMIN".equals(currentUser.getRole())) {
            userService.delete(id);
        }
        return "redirect:/users";
    }

    @PostMapping("/generate-code")
    public String generateCode(Model model, HttpSession session) {
        String code = userService.generateRegistrationCode();
        model.addAttribute("generatedCode", code);
        User currentUser = (User) session.getAttribute("user");
        model.addAttribute("isAdmin", "ADMIN".equals(currentUser.getRole()));
        model.addAttribute("activeMenu", "users");
        model.addAttribute("user", currentUser);
        if ("ADMIN".equals(currentUser.getRole())) {
            model.addAttribute("users", userService.findAll());
        } else {
            model.addAttribute("users", java.util.Arrays.asList(currentUser));
        }
        return "users";
    }
}

