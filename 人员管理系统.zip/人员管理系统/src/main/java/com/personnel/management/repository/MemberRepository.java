package com.personnel.management.repository;

import com.personnel.management.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
    List<Member> findByNameContaining(String name);
    Member findByIdCard(String idCard);
    
    @Query("SELECT m FROM Member m WHERE m.name LIKE %:keyword% OR m.idCard LIKE %:keyword% OR m.phone LIKE %:keyword%")
    List<Member> searchByKeyword(@Param("keyword") String keyword);
}

