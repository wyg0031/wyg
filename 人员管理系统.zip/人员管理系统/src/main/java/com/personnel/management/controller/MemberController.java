package com.personnel.management.controller;

import com.personnel.management.entity.Member;
import com.personnel.management.service.ExportService;
import com.personnel.management.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/members")
public class MemberController {
    @Autowired
    private MemberService memberService;

    @Autowired
    private ExportService exportService;

    @GetMapping
    public String list(@RequestParam(required = false) String keyword, Model model, HttpSession session) {
        List<Member> members;
        if (keyword != null && !keyword.isEmpty()) {
            members = memberService.search(keyword);
        } else {
            members = memberService.findAll();
        }
        model.addAttribute("members", members);
        model.addAttribute("keyword", keyword);
        model.addAttribute("activeMenu", "members");
        model.addAttribute("user", session.getAttribute("user"));
        return "members";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute Member member, 
                     @RequestParam(required = false) String birthDateStr,
                     @RequestParam(required = false) String joinDateStr) {
        if (birthDateStr != null && !birthDateStr.isEmpty()) {
            member.setBirthDateFromString(birthDateStr);
        }
        if (joinDateStr != null && !joinDateStr.isEmpty()) {
            member.setJoinDateFromString(joinDateStr);
        }
        memberService.save(member);
        return "redirect:/members";
    }

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file, Model model) {
        try {
            memberService.importFromExcel(file);
            model.addAttribute("success", "导入成功");
        } catch (Exception e) {
            model.addAttribute("error", "导入失败: " + e.getMessage());
        }
        return "redirect:/members";
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> export(@RequestParam(required = false) String keyword) throws IOException {
        List<Member> members;
        if (keyword != null && !keyword.isEmpty()) {
            members = memberService.search(keyword);
        } else {
            members = memberService.findAll();
        }
        
        byte[] data = exportService.exportMembersToExcel(members);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "团员信息.xlsx");
        return new ResponseEntity<>(data, headers, HttpStatus.OK);
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        memberService.delete(id);
        return "redirect:/members";
    }
}

