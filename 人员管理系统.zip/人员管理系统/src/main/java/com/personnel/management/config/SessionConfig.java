package com.personnel.management.config;

import com.personnel.management.entity.User;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Component
public class SessionConfig implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI();
        // 排除登录、注册、静态资源
        if (uri.equals("/login") || uri.equals("/register") || 
            uri.startsWith("/static") || uri.startsWith("/css") || 
            uri.startsWith("/js") || uri.startsWith("/img")) {
            return true;
        }

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null && !uri.equals("/login") && !uri.equals("/register")) {
            response.sendRedirect("/login");
            return false;
        }
        return true;
    }
}

