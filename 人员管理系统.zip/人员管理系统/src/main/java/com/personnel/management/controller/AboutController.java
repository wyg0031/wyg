package com.personnel.management.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class AboutController {
    @GetMapping("/about")
    public String about(Model model, HttpSession session) {
        model.addAttribute("activeMenu", "about");
        model.addAttribute("user", session.getAttribute("user"));
        return "about";
    }
}

