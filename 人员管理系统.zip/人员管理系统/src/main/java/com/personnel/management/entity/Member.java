package com.personnel.management.entity;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "members")
@Data
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name; // 姓名

    @Column(nullable = false)
    private String gender; // 性别

    @Column(nullable = false, unique = true, length = 18)
    private String idCard; // 身份证号

    private LocalDate birthDate; // 出生年月

    private String ethnicity; // 民族

    @Column(length = 11)
    private String phone; // 手机号码

    private String politicalStatus; // 政治面貌

    private String memberDevelopmentNumber; // 团员发展编号

    private LocalDate joinDate; // 入团时间

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @PrePersist
    protected void onCreate() {
        createTime = LocalDateTime.now();
        updateTime = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updateTime = LocalDateTime.now();
    }

    // 从字符串格式（20020330）解析出生日期
    public void setBirthDateFromString(String dateStr) {
        if (dateStr != null && dateStr.length() == 8) {
            try {
                int year = Integer.parseInt(dateStr.substring(0, 4));
                int month = Integer.parseInt(dateStr.substring(4, 6));
                int day = Integer.parseInt(dateStr.substring(6, 8));
                this.birthDate = LocalDate.of(year, month, day);
            } catch (Exception e) {
                // 解析失败，不设置
            }
        }
    }

    // 从字符串格式（2015-03）解析入团时间
    public void setJoinDateFromString(String dateStr) {
        if (dateStr != null) {
            try {
                if (dateStr.contains("-")) {
                    String[] parts = dateStr.split("-");
                    int year = Integer.parseInt(parts[0]);
                    int month = Integer.parseInt(parts[1]);
                    this.joinDate = LocalDate.of(year, month, 1);
                }
            } catch (Exception e) {
                // 解析失败，不设置
            }
        }
    }
}

