package com.personnel.management.config;

import com.personnel.management.entity.User;
import com.personnel.management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
        // 检查是否存在超级管理员，如果不存在则创建一个默认的
        if (!userRepository.existsByRole("ADMIN")) {
            User admin = new User();
            admin.setIdCard("000000000000000000"); // 默认身份证号
            admin.setPassword("admin123"); // 默认密码
            admin.setName("超级管理员");
            admin.setRole("ADMIN");
            userRepository.save(admin);
            System.out.println("========================================");
            System.out.println("默认超级管理员账号已创建！");
            System.out.println("用户名（身份证号）: 000000000000000000");
            System.out.println("密码: admin123");
            System.out.println("请首次登录后及时修改密码！");
            System.out.println("========================================");
        }
    }
}

