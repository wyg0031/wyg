package com.personnel.management.repository;

import com.personnel.management.entity.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {
    @Query("SELECT v FROM Volunteer v WHERE v.name LIKE %:keyword% OR v.idCard LIKE %:keyword% OR v.phone LIKE %:keyword%")
    List<Volunteer> searchByKeyword(@Param("keyword") String keyword);
}

