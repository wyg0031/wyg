package com.personnel.management.service;

import com.personnel.management.entity.Activity;
import com.personnel.management.entity.ActivityParticipant;
import com.personnel.management.repository.ActivityParticipantRepository;
import com.personnel.management.repository.ActivityRepository;
import com.personnel.management.repository.MemberRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActivityService {
    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private ActivityParticipantRepository participantRepository;

    @Autowired
    private MemberRepository memberRepository;

    public List<Activity> findAll() {
        return activityRepository.findAll();
    }

    public Activity findById(Long id) {
        return activityRepository.findById(id).orElse(null);
    }

    @Transactional
    public Activity save(Activity activity) {
        return activityRepository.save(activity);
    }

    @Transactional
    public void delete(Long id) {
        participantRepository.deleteByActivityId(id);
        activityRepository.deleteById(id);
    }

    public List<Activity> search(String keyword) {
        return activityRepository.searchByKeyword(keyword);
    }

    @Transactional
    public void addParticipants(Long activityId, List<String> participantNames) {
        participantRepository.deleteByActivityId(activityId);
        for (String name : participantNames) {
            ActivityParticipant participant = new ActivityParticipant();
            participant.setActivityId(activityId);
            participant.setParticipantName(name);
            participantRepository.save(participant);
        }
    }

    public List<String> getParticipantNames(Long activityId) {
        List<ActivityParticipant> participants = participantRepository.findByActivityId(activityId);
        List<String> names = new ArrayList<>();
        for (ActivityParticipant p : participants) {
            names.add(p.getParticipantName());
        }
        return names;
    }

    @Transactional
    public void importParticipantsFromExcel(MultipartFile file) throws IOException {
        InputStream inputStream = file.getInputStream();
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            try {
                String activityName = getCellValue(row, 0);
                String participantName = getCellValue(row, 1);

                // 查找活动
                List<Activity> activities = activityRepository.findByNameContaining(activityName);
                if (!activities.isEmpty()) {
                    Activity activity = activities.get(0);
                    ActivityParticipant participant = new ActivityParticipant();
                    participant.setActivityId(activity.getId());
                    participant.setParticipantName(participantName);
                    participantRepository.save(participant);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        workbook.close();
        inputStream.close();
    }

    private String getCellValue(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }
}

