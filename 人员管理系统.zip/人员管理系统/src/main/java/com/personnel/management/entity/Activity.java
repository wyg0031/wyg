package com.personnel.management.entity;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "activities")
@Data
public class Activity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name; // 活动名称

    private String location; // 活动地点

    @Column(nullable = false)
    private LocalDateTime startTime; // 活动开始时间

    @Column(nullable = false)
    private LocalDateTime endTime; // 活动结束时间

    private Double duration; // 活动时长（小时），保留一位小数

    private String remarks; // 备注

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @PrePersist
    protected void onCreate() {
        createTime = LocalDateTime.now();
        updateTime = LocalDateTime.now();
        calculateDuration();
    }

    @PreUpdate
    protected void onUpdate() {
        updateTime = LocalDateTime.now();
        calculateDuration();
    }

    // 计算活动时长（小时）
    private void calculateDuration() {
        if (startTime != null && endTime != null) {
            long minutes = java.time.Duration.between(startTime, endTime).toMinutes();
            // 保留一位小数，不四舍五入（向下取整）
            double hours = minutes / 60.0;
            this.duration = Math.floor(hours * 10.0) / 10.0;
        }
    }
}

