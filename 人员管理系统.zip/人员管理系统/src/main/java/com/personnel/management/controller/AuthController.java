package com.personnel.management.controller;

import com.personnel.management.entity.User;
import com.personnel.management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
public class AuthController {
    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String idCard, @RequestParam String password, 
                       HttpSession session, Model model) {
        java.util.Optional<User> user = userService.login(idCard, password);
        if (user.isPresent()) {
            session.setAttribute("user", user.get());
            return "redirect:/index";
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "login";
        }
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String idCard, @RequestParam String password,
                          @RequestParam String name, @RequestParam String registrationCode,
                          Model model) {
        boolean success = userService.register(idCard, password, name, registrationCode);
        if (success) {
            model.addAttribute("success", "注册成功，请登录");
            return "login";
        } else {
            model.addAttribute("error", "注册失败，请检查注册码是否正确");
            return "register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}

