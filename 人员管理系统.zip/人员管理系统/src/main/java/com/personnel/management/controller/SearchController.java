package com.personnel.management.controller;

import com.personnel.management.entity.Activity;
import com.personnel.management.entity.Member;
import com.personnel.management.entity.Volunteer;
import com.personnel.management.repository.ActivityParticipantRepository;
import com.personnel.management.repository.ActivityRepository;
import com.personnel.management.service.ExportService;
import com.personnel.management.service.MemberService;
import com.personnel.management.service.VolunteerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/search")
public class SearchController {
    @Autowired
    private MemberService memberService;

    @Autowired
    private VolunteerService volunteerService;

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private ActivityParticipantRepository participantRepository;

    @Autowired
    private ExportService exportService;

    @GetMapping
    public String search(@RequestParam(required = false) String keyword, Model model, HttpSession session) {
        if (keyword != null && !keyword.isEmpty()) {
            List<Member> members = memberService.search(keyword);
            List<Volunteer> volunteers = volunteerService.search(keyword);
            List<Activity> activities = activityRepository.searchByKeyword(keyword);

            model.addAttribute("members", members);
            model.addAttribute("volunteers", volunteers);
            model.addAttribute("activities", activities);
            model.addAttribute("keyword", keyword);
        }
        model.addAttribute("activeMenu", "search");
        model.addAttribute("user", session.getAttribute("user"));
        return "search";
    }

    @GetMapping("/export-word")
    public ResponseEntity<byte[]> exportToWord(@RequestParam String keyword) throws Exception {
        List<Member> members = memberService.search(keyword);
        List<Volunteer> volunteers = volunteerService.search(keyword);

        // 使用简单的Word生成方式（可以后续改进为使用Apache POI XWPF）
        String content = generateWordContent(keyword, members, volunteers);
        byte[] data = content.getBytes("UTF-8");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "搜索结果.doc");
        return new ResponseEntity<>(data, headers, HttpStatus.OK);
    }

    @GetMapping("/export-excel")
    public ResponseEntity<byte[]> exportToExcel(@RequestParam String activityName) throws Exception {
        byte[] data = exportService.exportActivityParticipantsToExcel(activityName);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "活动参与人员.xlsx");
        return new ResponseEntity<>(data, headers, HttpStatus.OK);
    }

    private String generateWordContent(String keyword, List<Member> members, List<Volunteer> volunteers) {
        StringBuilder sb = new StringBuilder();
        sb.append("搜索结果：").append(keyword).append("\n\n");
        
        if (!members.isEmpty()) {
            sb.append("团员信息：\n");
            for (Member m : members) {
                sb.append("姓名：").append(m.getName()).append("，身份证号：").append(m.getIdCard()).append("\n");
            }
            sb.append("\n");
        }
        
        if (!volunteers.isEmpty()) {
            sb.append("志愿者信息：\n");
            for (Volunteer v : volunteers) {
                sb.append("姓名：").append(v.getName()).append("，身份证号：").append(v.getIdCard()).append("\n");
            }
        }
        
        return sb.toString();
    }
}

