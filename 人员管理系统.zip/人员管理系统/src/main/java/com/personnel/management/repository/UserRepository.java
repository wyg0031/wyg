package com.personnel.management.repository;

import com.personnel.management.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByIdCard(String idCard);
    boolean existsByIdCard(String idCard);
    boolean existsByRole(String role);
}

