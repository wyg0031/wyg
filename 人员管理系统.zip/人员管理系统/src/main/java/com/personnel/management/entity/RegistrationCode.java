package com.personnel.management.entity;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "registration_codes")
@Data
public class RegistrationCode {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 32)
    private String code; // 注册码

    private Boolean used = false; // 是否已使用

    private LocalDateTime createTime;

    private LocalDateTime useTime;

    @PrePersist
    protected void onCreate() {
        createTime = LocalDateTime.now();
    }
}

