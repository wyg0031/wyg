package com.personnel.management.service;

import com.personnel.management.entity.Activity;
import com.personnel.management.entity.ActivityParticipant;
import com.personnel.management.entity.Member;
import com.personnel.management.entity.Volunteer;
import com.personnel.management.repository.ActivityParticipantRepository;
import com.personnel.management.repository.ActivityRepository;
import com.personnel.management.repository.MemberRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ExportService {
    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private ActivityParticipantRepository participantRepository;

    public byte[] exportMembersToExcel(List<Member> members) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("团员信息");

        // 创建标题行
        Row headerRow = sheet.createRow(0);
        String[] headers = {"姓名", "性别", "身份证号", "出生年月", "民族", "手机号码", "政治面貌", "团员发展编号", "入团时间"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            CellStyle style = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            style.setFont(font);
            cell.setCellStyle(style);
        }

        // 填充数据
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        int rowNum = 1;
        for (Member member : members) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(member.getName());
            row.createCell(1).setCellValue(member.getGender());
            row.createCell(2).setCellValue(member.getIdCard());
            row.createCell(3).setCellValue(member.getBirthDate() != null ? member.getBirthDate().format(dateFormatter) : "");
            row.createCell(4).setCellValue(member.getEthnicity());
            row.createCell(5).setCellValue(member.getPhone());
            row.createCell(6).setCellValue(member.getPoliticalStatus());
            row.createCell(7).setCellValue(member.getMemberDevelopmentNumber());
            row.createCell(8).setCellValue(member.getJoinDate() != null ? member.getJoinDate().format(dateFormatter) : "");
        }

        // 自动调整列宽
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        return outputStream.toByteArray();
    }

    public byte[] exportActivitiesToExcel(List<Activity> activities) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("活动记录");

        Row headerRow = sheet.createRow(0);
        String[] headers = {"活动名称", "活动地点", "开始时间", "结束时间", "活动时长(小时)", "备注"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            CellStyle style = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            style.setFont(font);
            cell.setCellStyle(style);
        }

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        int rowNum = 1;
        for (Activity activity : activities) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(activity.getName());
            row.createCell(1).setCellValue(activity.getLocation());
            row.createCell(2).setCellValue(activity.getStartTime().format(dateTimeFormatter));
            row.createCell(3).setCellValue(activity.getEndTime().format(dateTimeFormatter));
            row.createCell(4).setCellValue(activity.getDuration() != null ? activity.getDuration() : 0);
            row.createCell(5).setCellValue(activity.getRemarks());
        }

        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        return outputStream.toByteArray();
    }

    public byte[] exportActivityParticipantsToExcel(String activityName) throws IOException {
        List<Activity> activities = activityRepository.findByNameContaining(activityName);
        if (activities.isEmpty()) {
            return new byte[0];
        }

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("活动参与人员");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("活动名称");
        headerRow.createCell(1).setCellValue("参与人员姓名");

        int rowNum = 1;
        for (Activity activity : activities) {
            List<ActivityParticipant> participants = participantRepository.findByActivityId(activity.getId());
            for (ActivityParticipant participant : participants) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(activity.getName());
                row.createCell(1).setCellValue(participant.getParticipantName());
            }
        }

        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        return outputStream.toByteArray();
    }
}

