package com.personnel.management.controller;

import com.personnel.management.entity.User;
import com.personnel.management.repository.ActivityRepository;
import com.personnel.management.repository.MemberRepository;
import com.personnel.management.repository.VolunteerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class IndexController {
    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private VolunteerRepository volunteerRepository;

    @GetMapping({"/", "/index"})
    public String index(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        model.addAttribute("user", user);
        model.addAttribute("activeMenu", "index");
        model.addAttribute("memberCount", memberRepository.count());
        model.addAttribute("activityCount", activityRepository.count());
        model.addAttribute("volunteerCount", volunteerRepository.count());
        return "index";
    }
}

