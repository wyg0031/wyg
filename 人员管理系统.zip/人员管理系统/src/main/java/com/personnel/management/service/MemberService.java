package com.personnel.management.service;

import com.personnel.management.entity.Member;
import com.personnel.management.repository.MemberRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class MemberService {
    @Autowired
    private MemberRepository memberRepository;

    public List<Member> findAll() {
        return memberRepository.findAll();
    }

    public Member findById(Long id) {
        return memberRepository.findById(id).orElse(null);
    }

    @Transactional
    public Member save(Member member) {
        return memberRepository.save(member);
    }

    @Transactional
    public void delete(Long id) {
        memberRepository.deleteById(id);
    }

    public List<Member> search(String keyword) {
        return memberRepository.searchByKeyword(keyword);
    }

    @Transactional
    public List<Member> importFromExcel(MultipartFile file) throws IOException {
        List<Member> members = new ArrayList<>();
        InputStream inputStream = file.getInputStream();
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);

        // 跳过标题行
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            Member member = new Member();
            try {
                // 姓名
                member.setName(getCellValue(row, 0));
                // 性别
                member.setGender(getCellValue(row, 1));
                // 身份证号
                member.setIdCard(getCellValue(row, 2));
                // 出生年月（20020330格式）
                String birthDateStr = getCellValue(row, 3);
                member.setBirthDateFromString(birthDateStr);
                // 民族
                member.setEthnicity(getCellValue(row, 4));
                // 手机号码
                member.setPhone(getCellValue(row, 5));
                // 政治面貌
                member.setPoliticalStatus(getCellValue(row, 6));
                // 团员发展编号
                member.setMemberDevelopmentNumber(getCellValue(row, 7));
                // 入团时间（2015-03格式）
                String joinDateStr = getCellValue(row, 8);
                member.setJoinDateFromString(joinDateStr);

                // 检查是否已存在
                if (member.getIdCard() != null && !member.getIdCard().isEmpty()) {
                    Member existing = memberRepository.findByIdCard(member.getIdCard());
                    if (existing == null) {
                        memberRepository.save(member);
                        members.add(member);
                    }
                }
            } catch (Exception e) {
                // 跳过错误行
                e.printStackTrace();
            }
        }

        workbook.close();
        inputStream.close();
        return members;
    }

    private String getCellValue(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    // 处理数字，避免科学计数法
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }
}

