package com.personnel.management.controller;

import com.personnel.management.service.VolunteerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/volunteers")
public class VolunteerController {
    @Autowired
    private VolunteerService volunteerService;

    @GetMapping
    public String list(Model model, HttpSession session) {
        model.addAttribute("volunteers", volunteerService.findAll());
        model.addAttribute("activeMenu", "volunteers");
        model.addAttribute("user", session.getAttribute("user"));
        return "volunteers";
    }

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file, Model model) {
        try {
            volunteerService.importFromExcel(file);
            model.addAttribute("success", "导入成功");
        } catch (Exception e) {
            model.addAttribute("error", "导入失败: " + e.getMessage());
        }
        return "redirect:/volunteers";
    }
}

