package com.personnel.management.service;

import com.personnel.management.entity.RegistrationCode;
import com.personnel.management.entity.User;
import com.personnel.management.repository.RegistrationCodeRepository;
import com.personnel.management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RegistrationCodeRepository registrationCodeRepository;

    public Optional<User> login(String idCard, String password) {
        Optional<User> user = userRepository.findByIdCard(idCard);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user;
        }
        return Optional.empty();
    }

    @Transactional
    public boolean register(String idCard, String password, String name, String registrationCode) {
        // 验证注册码
        Optional<RegistrationCode> code = registrationCodeRepository.findByCode(registrationCode);
        if (!code.isPresent() || code.get().getUsed()) {
            return false;
        }

        // 检查用户是否已存在
        if (userRepository.existsByIdCard(idCard)) {
            return false;
        }

        // 创建用户
        User user = new User();
        user.setIdCard(idCard);
        user.setPassword(password);
        user.setName(name);
        user.setRole("USER");
        userRepository.save(user);

        // 标记注册码为已使用
        RegistrationCode rc = code.get();
        rc.setUsed(true);
        rc.setUseTime(java.time.LocalDateTime.now());
        registrationCodeRepository.save(rc);

        return true;
    }

    public User findById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Transactional
    public User save(User user) {
        return userRepository.save(user);
    }

    @Transactional
    public void delete(Long id) {
        userRepository.deleteById(id);
    }

    public String generateRegistrationCode() {
        String code = UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        RegistrationCode registrationCode = new RegistrationCode();
        registrationCode.setCode(code);
        registrationCodeRepository.save(registrationCode);
        return code;
    }
}

