package com.personnel.management.entity;

import lombok.Data;
import javax.persistence.*;

@Entity
@Table(name = "activity_participants")
@Data
public class ActivityParticipant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long activityId; // 活动ID

    @Column(nullable = false)
    private String participantName; // 参与人员姓名

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "activityId", insertable = false, updatable = false)
    private Activity activity;
}

