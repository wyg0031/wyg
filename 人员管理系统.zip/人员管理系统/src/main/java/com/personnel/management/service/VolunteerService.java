package com.personnel.management.service;

import com.personnel.management.entity.Volunteer;
import com.personnel.management.repository.VolunteerRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class VolunteerService {
    @Autowired
    private VolunteerRepository volunteerRepository;

    public List<Volunteer> findAll() {
        return volunteerRepository.findAll();
    }

    public Volunteer findById(Long id) {
        return volunteerRepository.findById(id).orElse(null);
    }

    @Transactional
    public Volunteer save(Volunteer volunteer) {
        return volunteerRepository.save(volunteer);
    }

    @Transactional
    public void delete(Long id) {
        volunteerRepository.deleteById(id);
    }

    public List<Volunteer> search(String keyword) {
        return volunteerRepository.searchByKeyword(keyword);
    }

    @Transactional
    public List<Volunteer> importFromExcel(MultipartFile file) throws IOException {
        List<Volunteer> volunteers = new ArrayList<>();
        InputStream inputStream = file.getInputStream();
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);

        // 跳过标题行
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            Volunteer volunteer = new Volunteer();
            try {
                volunteer.setName(getCellValue(row, 0));
                volunteer.setIdCard(getCellValue(row, 1));
                volunteer.setPhone(getCellValue(row, 2));
                volunteer.setAddress(getCellValue(row, 3));
                volunteer.setOrganization(getCellValue(row, 4));
                volunteer.setNotes(getCellValue(row, 5));

                if (volunteer.getName() != null && !volunteer.getName().isEmpty()) {
                    volunteerRepository.save(volunteer);
                    volunteers.add(volunteer);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        workbook.close();
        inputStream.close();
        return volunteers;
    }

    private String getCellValue(Row row, int cellIndex) {
        Cell cell = row.getCell(cellIndex);
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }
}

