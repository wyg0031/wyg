package com.personnel.management.entity;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 18)
    private String idCard; // 身份证号，作为用户名

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String name;

    private String avatar; // 头像路径

    @Column(nullable = false)
    private String role; // ADMIN: 超级管理员, USER: 普通用户

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @PrePersist
    protected void onCreate() {
        createTime = LocalDateTime.now();
        updateTime = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updateTime = LocalDateTime.now();
    }
}

