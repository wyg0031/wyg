package com.personnel.management.repository;

import com.personnel.management.entity.Activity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActivityRepository extends JpaRepository<Activity, Long> {
    List<Activity> findByNameContaining(String name);
    
    @Query("SELECT a FROM Activity a WHERE a.name LIKE %:keyword% OR a.location LIKE %:keyword%")
    List<Activity> searchByKeyword(@Param("keyword") String keyword);
}

